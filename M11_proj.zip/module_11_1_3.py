# Обзор сторонних библиотек Python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

p = pd.read_excel('./OkPopul_Comp2024_Site.xlsx',sheet_name='Всего',skiprows=8,header=None,keep_default_na=True, usecols ='A:B', nrows=48)
# исходные данные - вывод в консоль
print('До сортировки')
print(p)

# форма массива
print('Форма массива', p.shape)
# сортировка с изменением
p.sort_values(by=[1],ascending=True,inplace=True)
print('После сортировки')
print('Численность населения по 48-ми регионам России')
print(p)
# преобразуем в массив для бара
x = list(p[0])
y = list(p[1])

plt.barh(x,y,height=1) # orientation
plt.ylabel('Регион')
plt.xlabel('Численность населения по 48-ми регионам России, млн. чел')
plt.show()
# по идее можно было бы вывести по всем регионам, но надо разбивать на 2 листа


